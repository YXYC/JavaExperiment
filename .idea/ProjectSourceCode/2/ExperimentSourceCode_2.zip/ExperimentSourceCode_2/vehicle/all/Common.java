package ExperimentSourceCode_2.vehicle.all;

public interface Common {
    double runTime(double a,double b,double c);
}
