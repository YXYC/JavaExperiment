package ExperimentSourceCode_9.BANK.BankClient;

import ExperimentSourceCode_9.BANK.BankClient.Client.gui.LogOnJFrame;

public class Main {
    public static void main(String[] args) {
        new LogOnJFrame();
    }
}