package ExperimentSourceCode_9.BANK.bean;

import java.io.Serializable;

/**
 * 创建用户类，分为账号密码（登陆部分）
 */
public class User implements Serializable {

    private String username;
    private String password;


    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    @Override
    public String toString() {
        return "User{" +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
