package ExperimentSourceCode_7.Chat.Server.JDBC.Dao;

import ExperimentSourceCode_7.Chat.Bean.user;

public interface UserDao {
    user Login (String Username,String password);

}
